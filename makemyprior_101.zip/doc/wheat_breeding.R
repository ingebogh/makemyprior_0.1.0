## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup--------------------------------------------------------------------
library(makemyprior)

## -----------------------------------------------------------------------------

# scaling the matrices so the typical variance is 1
wheat_data_scaled <- wheat_data
wheat_data_scaled$Q_a <- scale_precmat(wheat_data$Q_a)
wheat_data_scaled$Q_d <- scale_precmat(wheat_data$Q_d)
wheat_data_scaled$Q_x <- scale_precmat(wheat_data$Q_x)

formula <- y ~
  mc(a, model = "generic0", Cmatrix = Q_a, constr = TRUE) +
  mc(d, model = "generic0", Cmatrix = Q_d, constr = TRUE) +
  mc(x, model = "generic0", Cmatrix = Q_x, constr = TRUE)

prior <- make_prior(formula, wheat_data_scaled, prior = list(
  tree = "s1 = (d, x); s2 = (a, s1); s3 = (s2, eps)",
  w = list(s1 = list(prior = "pcM", param = c(0.67, 0.8)),
           s2 = list(prior = "pcM", param = c(0.85, 0.8)),
           s3 = list(prior = "pc0", param = 0.25))))


## ---- fig.width = 5, fig.height = 3-------------------------------------------
plot_prior(prior) # or plot(prior)

## ---- fig.width = 5, fig.height = 3-------------------------------------------
plot_tree_structure(prior)

## ---- eval = F----------------------------------------------------------------
#  
#  posterior <- inference_stan(prior, iter = 15000, warmup = 5000,
#                              chains = 1, seed = 1)
#  
#  plot_posterior_stan(posterior, param = "prior", prior = TRUE) # or plot(posterior, param = "prior", prior = TRUE)
#  

