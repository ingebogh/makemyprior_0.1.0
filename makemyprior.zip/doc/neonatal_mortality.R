## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup--------------------------------------------------------------------
library(makemyprior)

## -----------------------------------------------------------------------------

graph_path <- paste0(path.package("makemyprior"), "/neonatal.graph")

formula <- y ~ urban + mc(nu) + mc(v) +
  mc(u, model = "besag", graph = graph_path, scale.model = TRUE)

set.seed(1)
find_pc_prior_param(lower = 0.1, upper = 10, prob = 0.9, N = 2e5)


## ---- eval = FALSE------------------------------------------------------------
#  
#  prior <- make_prior(
#    formula, neonatal_data, family = "binomial",
#    prior = list(tree = "s1 = (u, v); s2 = (s1, nu)",
#                 w = list(s1 = list(prior = "pc0", param = 0.25),
#                          s2 = list(prior = "pc1", param = 0.75)),
#                 V = list(s2 = list(prior = "pc",
#                                    param = c(3.35, 0.05)))))

## ---- fig.width = 5, fig.height = 3, eval = F---------------------------------
#  plot_prior(prior) # or plot(prior)

## ---- fig.width = 5, fig.height = 3, eval = F---------------------------------
#  plot_tree_structure(prior)

## ---- eval = F----------------------------------------------------------------
#  
#  posterior <- inference_stan(prior, iter = 15000, warmup = 5000,
#                              seed = 1, init = "0", chains = 1)
#  
#  plot_posterior_stan(posterior, param = "prior", plot_prior = TRUE)
#  

