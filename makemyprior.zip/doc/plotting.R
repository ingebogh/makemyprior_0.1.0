## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup--------------------------------------------------------------------
library(makemyprior)

## ---- eval = F----------------------------------------------------------------
#  
#  p <- 10
#  m <- 10
#  n <- m*p
#  
#  set.seed(1)
#  data <- list(a = rep(1:p, each = m),
#               b = rep(1:m, times = p),
#               x = runif(n))
#  
#  data$y <- data$x + rnorm(p, 0, 0.5)[data$a] +
#    rnorm(m, 0, 0.3)[data$b] + rnorm(n, 0, 1)
#  
#  formula <- y ~ x + mc(a) + mc(b)
#  
#  prior <- make_prior(formula, data, family = "gaussian",
#                      intercept_prior = c(0, 1000),
#                      covariate_prior = list(x = c(0, 100)))
#  
#  plot_prior(prior) # or plot(prior)
#  
#  posterior <- inference_stan(prior, iter = 2500, warmup = 500)
#  
#  plot_posterior_stdev(posterior)
#  plot_posterior_variance(posterior)
#  plot_posterior_precision(posterior)
#  
#  plot_posterior_stan(posterior, param = "prior", prior = TRUE)
#  
#  plot_fixed_posterior(posterior)
#  

## ---- eval = F----------------------------------------------------------------
#  
#  posterior <- inference_inla(prior)
#  
#  plot_posterior_stdev(posterior)
#  plot_posterior_variance(posterior)
#  plot_posterior_precision(posterior)
#  
#  plot_fixed_posterior(posterior)
#  

