## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----setup--------------------------------------------------------------------
library(makemyprior)

## -----------------------------------------------------------------------------

formula <- y ~ -1 + mc(row) + mc(col) + mc(iid, constr = T) +
  mc(rw2, model = "rw2", constr = TRUE, lin_constr = TRUE)

prior <- make_prior(
  formula, latin_data,
  prior = list(tree = "s1 = (iid, rw2);
                               s2 = (row, col, s1); s3 = (s2, eps)",
               w = list(s1 = list(prior = "pc1", param = 0.75),
                        s2 = list(prior = "dirichlet"),
                        s3 = list(prior = "pc0", param = 0.25))))


## ---- fig.width = 6, fig.height = 3-------------------------------------------
plot_prior(prior) # or plot(prior)

## ---- fig.width = 3, fig.height = 3-------------------------------------------
plot_tree_structure(prior)

## ---- eval = F----------------------------------------------------------------
#  
#  posterior <- inference_stan(prior, iter = 6500, warmup = 5000,
#                              seed = 1, init = "0", chains = 1)
#  plot_posterior_stan(posterior, param = "prior", prior = TRUE)
#  

