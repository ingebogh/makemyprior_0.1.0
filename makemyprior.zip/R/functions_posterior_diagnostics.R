

# plotting the prior and posterior of each effect

# some of these are also used in the shiny-app

# for one component, either CW or total variance
# all priors are plotted on variance scale
df_prior_variance <- function(prior_data, node_data, var_type){

  if (is.null(prior_data$prior)) return(data.frame())

  if (prior_data$prior == "pc0"){
    xx <- c(seq(1, 20, 0.1))
    yy <- dexp(sqrt(xx), rate = -log(prior_data$param[2])/prior_data$param[1]) * 1/(2*sqrt(xx))
  } else if (prior_data$prior == "invgam"){
    a <- prior_data$param[1]
    b <- prior_data$param[2] # input is rate, but we plot using scale = 1/rate
    xx <- seq(0, 2/(a*b), 200)
    yy <- b^a/(gamma(a)) * (1/xx)^(a+1) * exp(-b/xx)
  } else if (prior_data$prior == "hc"){
    xx <- sqrt(seq(0, 10000, 10))
    yy <- 2*prior_data$param[1]/(pi*(xx^2 + prior_data$param[1]^2)) * 1/(2*sqrt(xx))
  } else if (prior_data$prior == "jeffreys"){
    xx <- seq(0, 3, 0.01)
    yy <- 1/xx
  } else {
    return(data.frame()) # if this component does not have a CW prior
  }

  title <- if (var_type == "total") bquote(V[.(paste0(
    get_node_name(node_data, get_leaf_nodes(node_data, prior_data$id)), sep = "", collapse = ","))]) else bquote(sigma[.(prior_data$name)]^2)

  df <- data.frame(x = xx, y = yy, param = as.character(as.expression(title)))

  return(df)

}

# for one split
plot_diri_w <- function(prior_data, node_data){

  no_children <- prior_data$no_children
  param <- get_diri_param(no_children)

  titles <- character()
  under <- paste0(get_node_name(node_data, get_leaf_nodes(node_data, prior_data$id)), sep = "", collapse = ",")
  for (ind in 1:(no_children-1)){
    titles[ind] <- as.expression(bquote(omega[frac(.(as.character(paste0(
      get_node_name(node_data, get_leaf_nodes(node_data, prior_data$children[ind])), sep = "", collapse = ","))), .(under))]))
  }

  xx <- seq(0, 1, 0.01)
  df <- data.frame(x = xx, y = dbeta(xx, param, param*(no_children-1)),
                   param = rep(as.character(titles), each = length(xx)))

  return(df)

}

# for one split
plot_pc_w <- function(prior_data, weight_data, node_data){

  # names of the child nodes, so it is clear where the base model for the PC prior is
  under <- paste0(as.character(get_node_name(node_data, get_leaf_nodes(node_data, prior_data$id))), sep = "", collapse = ",")
  over <- paste0(as.character(get_node_name(node_data, get_leaf_nodes(node_data, prior_data$param$above_node))), sep = "", collapse = ",")
  title <- as.expression(bquote(omega[frac(.(over), .(under))]))

  xx <- seq(0, 1, 0.01)
  yy <- eval_spline_prior(xx, weight_data, F)

  df <- data.frame(x = xx, y = yy, param = as.character(title))

  return(df)

}

# return just the name of the weight
plot_pc_w_nocalc <- function(prior_data, node_data){

  # names of the child nodes, so it is clear where the base model for the PC prior is
  under <- paste0(as.character(get_node_name(node_data, get_leaf_nodes(node_data, prior_data$id))), sep = "", collapse = ",")
  over <- paste0(as.character(get_node_name(node_data, get_leaf_nodes(node_data, prior_data$param$above_node))), sep = "", collapse = ",")
  title <- as.expression(bquote(omega[frac(.(over), .(under))]))

  return(data.frame(x = rep(prior_data$param$median, 10), y = seq(0, 1, length.out = 10), param = as.character(title)))

}


# making data-frame for plotting prior or posteriors, or both for Stan
make_dataframe_for_plotting <- function(type = c("prior", "posterior", "both"), res){

  if (class(res) == "mmp_stan"){
    prior_obj <- res$prior
    res_stan <- res$stan
    stan_data <- res$stan_data
  } else if (class(res) == "mmp_prior"){
    prior_obj <- res
    type <- "prior" # can only plot prior if that is the only object that is provided
  } else {
    stop("Must provide object of class 'mmp_stan' or 'mmp_prior'.", call. = FALSE)
  }

  type <- match.arg(type)

  if (type == "prior" || type == "both"){

    df_pri <- data.frame()

    # for CW priors:
    for (i in 1:length(prior_obj$prior_data$cw_priors)){
      df_pri <- rbind(df_pri, df_prior_variance(prior_obj$prior_data$cw_priors[[i]], prior_obj$node_data, "cw"))
    }

    # for total variances
    for (i in seq_len(length(prior_obj$prior_data$total_variance))){
      tmp <- df_prior_variance(prior_obj$prior_data$total_variance[[i]], prior_obj$node_data, "total")
      if (!(type == "both" && prior_obj$prior_data$total_variance[[i]]$prior == "jeffreys")){
        # don't plot jeffreys prior for posterior total variance
        df_pri <- rbind(df_pri, tmp)
      }
    }

    # for HD priors
    for (i in seq_len(length(prior_obj$prior_data$weights))){
      if (prior_obj$prior_data$weights[[i]]$prior == "pc"){
        df_pri <- rbind(df_pri, plot_pc_w(prior_obj$prior_data$weights[[i]], prior_obj$weight_priors[[i]], prior_obj$node_data))
      } else { # dirichlet
        df_pri <- rbind(df_pri, plot_diri_w(prior_obj$prior_data$weights[[i]], prior_obj$node_data))
      }
    }

  }

  if (type == "posterior" || type == "both"){

    df_post <- data.frame()

    samps <- rstan::extract(res_stan, "theta")$theta

    # for CW priors:
    for (i in 1:length(prior_obj$prior_data$cw_priors)){

      if (prior_obj$prior_data$cw_priors[[i]]$prior != ""){

        xx <- exp(samps[,i])
        title <- as.expression(bquote(sigma[.(prior_obj$prior_data$cw_priors[[i]]$name)]^2))

        df_post <- rbind(df_post, data.frame(x = xx, param = as.character(title)))

      }

    }

    # for total variances
    for (i in seq_len(length(prior_obj$prior_data$total_variance))){

      if (is.null(prior_obj$prior_data$total_variance[[i]]$prior)) next

      xx <- rowSums(exp(samps[,stan_data$which_hd]))
      title <- as.expression(bquote(V[.(paste0(
        get_node_name(prior_obj$node_data,
                      get_leaf_nodes(prior_obj$node_data,prior_obj$prior_data$total_variance[[i]]$id)), sep = "", collapse = ","))]))

      df_post <- rbind(df_post, data.frame(x = xx, param = as.character(title)))

    }

    # for HD priors
    for (i in seq_len(length(prior_obj$prior_data$weights))){

      if (prior_obj$prior_data$weights[[i]]$prior == "pc"){

        # calculate the correct variances over and under fraction bar
        ind2 <- stan_data$row_index_hd_pr_plot[i]
        over <- rowSums(as.matrix(exp(samps[,stan_data$w_o[ind2,] == 1])))
        under <- rowSums(as.matrix(exp(samps[,stan_data$w_u[ind2,] == 1])))

        t_under <- paste0(get_node_name(prior_obj$node_data, get_leaf_nodes(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$id)), sep = "", collapse = ",")
        t_over <- as.character(
          paste0(get_node_name(prior_obj$node_data,
                               get_leaf_nodes(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$param$above_node)),
          sep = "", collapse = ","))
        title <- as.expression(bquote(omega[frac(.(t_over), .(t_under))]))

        df_post <- rbind(df_post, data.frame(x = over/under, param = as.character(title)))

      } else { # dirichlet

        for (ind in 1:(prior_obj$prior_data$weights[[i]]$no_children-1)){

          ind2 <- stan_data$row_index_hd_pr_plot[i]+ind-1

          over <- rowSums(as.matrix(exp(samps[,stan_data$w_o[ind2,] == 1])))
          under <- rowSums(as.matrix(exp(samps[,stan_data$w_u[ind2,] == 1])))

          t_under <- paste0(get_node_name(prior_obj$node_data, get_leaf_nodes(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$id)), sep = "", collapse = ",")
          t_over <- as.character(
            paste0(get_node_name(prior_obj$node_data,
                                 get_leaf_nodes(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$children[ind]))),
            sep = "", collapse = ",")
          title <- as.expression(bquote(omega[frac(.(t_over), .(t_under))]))

          df_post <- rbind(df_post, data.frame(x = over/under, param = as.character(title)))

        }

      }

    }

  }

  df <- if (type == "prior") df_pri else if (type == "posterior") df_post else list(prior = df_pri, posterior = df_post)

  return(df)

}

df_posteriors_inla <- function(res, type = c("variance", "stdev", "precision"), axes = list()){

  type <- match.arg(type)

  if (type == "variance"){
    myfun <- function(x) 1/x
  } else if (type == "stdev") {
    myfun <- function(x) 1/sqrt(x)
  } else {
    myfun <- function(x) x
  }

  randeff_names <- names(res$prior$data$random)

  titles <- c()

  for (ind in seq_len(length(randeff_names))){
    titles[ind] <-
      if (type == "variance") {
        as.expression(bquote(sigma[.(randeff_names[ind])]^2))
      } else if (type == "standard deviation"){
        as.expression(bquote(sigma[.(randeff_names[ind])]))
      } else {
        as.expression(bquote(1/sigma[.(randeff_names[ind])]^2))
      }
  }

  df_post <- data.frame()

  for (ind in 1:length(res$inla$marginals.hyperpar)){

    thispar <- names(res$inla$marginals.hyperpar)[ind]
    thispar <- strsplit(thispar, "Precision for ")[[1]][2]
    if (res$prior$family == "gaussian" && !is.na(thispar) && thispar == "the Gaussian observations"){
      thispar <- "eps"
    }
    this_title <- titles[randeff_names == thispar]

    title <- if (type == "variance") {
      as.expression(bquote(sigma[.(thispar)]^2))
    } else if (type == "stdev"){
      as.expression(bquote(sigma[.(thispar)]))
    } else {
      as.expression(bquote(1/sigma[.(thispar)]^2))
    }

    tmp <- as.data.frame(inla.tmarginal(myfun, res$inla$marginals.hyperpar[[ind]]))

    if (length(which(names(axes) == thispar)) > 0){

      tmp_axes <- axes[[which(names(axes) == thispar)]]
      tmp2 <- tmp[tmp$x >= min(tmp_axes) & tmp$x <= max(tmp_axes),]
      if (nrow(tmp2) >= 2) tmp <- tmp2 # only change the axes if we have at least two points

    }

    tmp$param <- as.character(this_title)

    df_post <- rbind(
      df_post,
      tmp
    )

  }

  df_post$param <- factor(df_post$param, levels = as.character(titles))

  return(df_post)

  # gg1 <- ggplot(df_post, aes(x = x, y = y)) +
  #   geom_line() +
  #   facet_wrap(~param, labeller = label_parsed, scales = "free") +
  #   # theme(strip.text = element_text(size = 14, color = "white")) +
  #   ylab("Density") +
  #   theme(axis.title.x = element_blank()) +
  #   theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
  #         panel.grid.major = element_line(color = gray(0.85)),
  #         panel.grid.minor = element_line(color = gray(0.92))) +
  #   theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
  #         strip.text = element_text(color = "black", size = 15))
  #
  # return(gg1)

}

df_posterior_variances <- function(res, param = "variance"){

  samps <- rstan::extract(res$stan, "theta")$theta

  if (param == "variance"){
    titles <- sapply(as.character(res$prior$node_data$orig_nodedata$label), function(x) as.expression(bquote(sigma[.(x)]^2)))

    df <- data.frame(
      x = exp(unlist(c(samps))),
      param = factor(rep(as.character(titles), each = nrow(samps)), levels = titles)
    )
  } else if (param == "stdev"){
    titles <- sapply(as.character(res$prior$node_data$orig_nodedata$label), function(x) as.expression(bquote(sigma[.(x)])))

    df <- data.frame(
      x = exp(unlist(c(samps))/2),
      param = factor(rep(as.character(titles), each = nrow(samps)), levels = titles)
    )
  } else if (param == "precision"){
    titles <- sapply(as.character(res$prior$node_data$orig_nodedata$label), function(x) as.expression(bquote(1/sigma[.(x)]^2)))

    df <- data.frame(
      x = exp(-unlist(c(samps))),
      param = factor(rep(as.character(titles), each = nrow(samps)), levels = titles)
    )
  }

  return(df)

  # gg1 <- ggplot(df, aes(x = x, y = ..density..)) +
  #   geom_histogram(col = gray(0.5), fill = "#8E8D8A", bins = 40) +
  #   facet_wrap(~name, labeller = label_parsed, scales = "free") +
  #   # theme(strip.text = element_text(size = 14, color = "white")) +
  #   ylab("Density") +
  #   theme(axis.title.x = element_blank()) +
  #   theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
  #         panel.grid.major = element_line(color = gray(0.85)),
  #         panel.grid.minor = element_line(color = gray(0.92))) +
  #   theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
  #         strip.text = element_text(color = "black", size = 15))
  # # theme(strip.background = element_rect(fill = "#8E8D8A", color = gray(0.5)),
  # #       strip.text = element_text(color = plot_text_color, size = 15))
  #
  # return(gg1)

}



#' Plotting the prior tree structure graph
#'
#' Can only be used for visualization in R.
#' @param obj An object from \code{make_prior}, \code{inference_stan}, \code{inference_inla}, or \code{makemyprior_gui}
#' @param nodenames Custom names for each node (optional). Given as a named list with the default names as list names, and the
#' new names as list elements.
#' Do not need to provide all.
#' @keywords plot
#' @return A \link[visNetwork]{visNetwork} with the tree graph
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_tree_structure <- function(obj, nodenames){

  if (class(obj) %in% c("mmp_inla", "mmp_stan")) obj <- obj$prior
  if (!class(obj) == "mmp_prior") stop("Provide an object with class 'mmp_prior', 'mmp_stan' or 'mmp_inla'.")

  nd <- list(x = obj$node_data)

  nd$x <- update_basemodel_edges(nd$x, obj$prior_data$weights)

  tmp_nodes <- nd$x$nodes
  tmp_nodes$color.background <- node_palette(calc_variance_proportions(nd$x)$nodes$varprop)
  tmp_nodes$color.background[tmp_nodes$status == "detached"] <- detached_node_color
  tmp_nodes$color.highlight.background <- tmp_nodes$color.background

  if (!missing(nodenames)){
    for (i in seq_len(length(nodenames))){
      tmp_nodes$label[which(tmp_nodes$label == names(nodenames)[i])] <- nodenames[[i]]
    }
  }

  tmp_edges <- nd$x$edges
  tmp_edges$width <- tmp_edges$width*5 # to get a bit thicker edges in the graph
  if (nrow(tmp_edges) > 0) tmp_edges <- cbind(tmp_edges, arrows = "to", hidden = FALSE)

  tmp_edges <- set_detached_edges(tmp_nodes, tmp_edges)
  tmp_edges$label <- ""

  nn <- visNetwork::visNetwork(tmp_nodes, tmp_edges, background = "white")
  nn <- visNetwork::visHierarchicalLayout(nn)
  nn <- visNetwork::visEdges(nn, color = list(highlight = node_highlight_border_color),
                             arrowStrikethrough = F, selectionWidth = 1, smooth = FALSE,
                             font = list(color = node_border_color, size = 14, vadjust = 35,
                                         # background = "#EAE7DC", # background does not move with vadjust
                                         strokeWidth = 0, bold = TRUE)
  )
  nn <- visNetwork::visNodes(nn,
                             color = list(border = node_border_color,
                                          highlight = list(border = node_highlight_border_color)),
                             borderWidth = 1,
                             #borderWidthSelected = 1,
                             font = list(background = "white", color = node_border_color))
  nn <- visNetwork::visOptions(nn, highlightNearest = FALSE)
  nn <- visNetwork::visInteraction(nn, F, F, F, F, F, F, F, F, F, F, F, zoomView = F)

  return(nn)

}



#' Plotting prior distributions
#'
#' Function for plotting the prior distributions of the random effects on the scale of the parameters chosen
#' @param obj An object from \code{make_prior}, \code{inference_stan}, \code{inference_inla}, or \code{makemyprior_gui}
#' @keywords plot
#' @return A \link[ggplot2]{ggplot} with the prior distributions.
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_prior <- function(obj){

  if (class(obj) %in% c("mmp_stan", "mmp_inla")){
    obj <- obj$prior
  } else if (class(obj) != "mmp_prior") stop("Invalid input.")

  df <- make_dataframe_for_plotting("prior", obj)

  gg <- ggplot(df, aes(x = x, y = y)) + geom_line(na.rm = TRUE) +
    facet_wrap(~param, labeller = label_parsed, scales = "free") +
    # theme(strip.text = element_text(size = 14, color = "white")) +
    ylab("Density") +
    ylim(0, NA) +
    theme(axis.title.x = element_blank()) +
    theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
          panel.grid.major = element_line(color = gray(0.85)),
          panel.grid.minor = element_line(color = gray(0.92))) +
    theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
          strip.text = element_text(color = "black", size = 15))
    # theme(strip.background = element_rect(fill = "#8E8D8A", color = gray(0.5)),
    #       strip.text = element_text(color = plot_text_color, size = 15))

  return(gg)

}


#' Plotting posterior distributions
#'
#' Function for plotting the posterior distributions of the random effect variances
#' on the scale of the tree parameterization.
#' @param obj An object from \code{inference_stan}
#' @param param A string indicating parameterization of plot.
#' \code{"prior"} for scale of parameters,
#' \code{"variance"}, \code{"stdev"} and \code{"precision"} also possible.
#' @param prior Include prior in the plot? Only possible for \code{param = "prior"}.
#' Note that if Jeffreys' prior is used for the total variance, it will not be included in the plot.
#' @keywords plot
#' @return A \link[ggplot2]{ggplot} with the posterior distributions.
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_posterior_stan <- function(obj, param = c("prior", "variance", "stdev", "precision"), prior = FALSE){

  if (class(obj) == "mmp_inla") stop("You cannot use a posterior fitted with inla for this function. Use 'plot_posterior_variance/stdev/precision' instead.")
  if (class(obj) != "mmp_stan") stop("Invalid input.")
  param <- match.arg(param)
  if (param != "prior") prior <- FALSE

  if (param == "prior"){
    if (prior){
      df <- make_dataframe_for_plotting("both", obj)
      gg <- ggplot() +
        geom_histogram(data = df$posterior, mapping = aes(x = x, y = ..density..), col = gray(0.5), fill = "#8E8D8A", bins = 40) +
        geom_line(data = df$pri, mapping = aes(x = x, y = y), na.rm = TRUE) +
        facet_wrap(~param, labeller = label_parsed, scales = "free") +
        # theme(strip.text = element_text(size = 14, color = "white")) +
        ylab("Density") +
        theme(axis.title.x = element_blank()) +
        theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
              panel.grid.major = element_line(color = gray(0.85)),
              panel.grid.minor = element_line(color = gray(0.92))) +
        theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
              strip.text = element_text(color = "black", size = 15))
    } else {
      df <- make_dataframe_for_plotting("posterior", obj)
      gg <- ggplot(df, aes(x = x, y = ..density..)) + geom_histogram(col = gray(0.5), fill = "#8E8D8A", bins = 40) +
        facet_wrap(~param, labeller = label_parsed, scales = "free") +
        # theme(strip.text = element_text(size = 14, color = "white")) +
        ylab("Density") +
        theme(axis.title.x = element_blank()) +
        theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
              panel.grid.major = element_line(color = gray(0.85)),
              panel.grid.minor = element_line(color = gray(0.92))) +
        theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
              strip.text = element_text(color = "black", size = 15))
    }
  } else {
    if (param == "variance"){
      gg <- plot_posterior_variance(obj)
    } else if (param == "stdev"){
      gg <- plot_posterior_stdev(obj)
    } else {
      gg <- plot_posterior_precision(obj)
    }
  }

  return(gg)

}


#' Plotting posterior distributions
#'
#' Function for plotting the posterior distributions of the coefficients of the fixed effects
#' @param obj An object from \code{inference_stan} or \code{inference_inla}
#' @keywords plot
#' @return A \link[ggplot2]{ggplot} with the posterior distributions.
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_fixed_posterior <- function(obj){

  df_post <- data.frame()

  if (class(obj) == "mmp_stan"){

    samps <- rstan::extract(obj$stan, c("intercept", "coeff"))

    if (obj$prior$use_intercept){
      title <- expression(mu)
      # xx <- seq(min(samps$intercept[,1]), max(samps$intercept[,1]), length.out = 200)
      df_post <- rbind(df_post, data.frame(x = samps$intercept[,1], param = as.character(title)))
    }

    for (i in seq_len(length(obj$prior$data$fixed))){
      title <- as.expression(bquote(beta[.(names(obj$prior$data$fixed)[i])]))
      # xx <- seq(min(samps$coeff[,i]), max(samps$coeff[,i]), length.out = 200)
      df_post <- rbind(df_post, data.frame(x = samps$coeff[,i], param = as.character(title)))
    }

    gg <- ggplot() +
      geom_histogram(data = df_post, mapping = aes(x = x, y = ..density..), col = gray(0.5), fill = "#8E8D8A", bins = 40) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))
    # theme(strip.background = element_rect(fill = "#8E8D8A", color = gray(0.5)),
    #       strip.text = element_text(color = plot_text_color, size = 15))

  } else if (class(obj) == "mmp_inla"){

    if (obj$prior$use_intercept){
      df_post <- rbind(df_post,
                       data.frame(x = obj$inla$marginals.fixed$`(Intercept)`[,1],
                                  y = obj$inla$marginals.fixed$`(Intercept)`[,2],
                                  param = as.character(expression(mu))))
    }

    for (i in seq_len(length(obj$prior$data$fixed))){
      title <- as.expression(bquote(beta[.(names(obj$prior$data$fixed)[i])]))
      df_post <- rbind(df_post,
                       data.frame(x = obj$inla$marginals.fixed[[i]][,1],
                                  y = obj$inla$marginals.fixed[[i]][,2],
                                  param = as.character(title)))
    }

    gg <- ggplot() +
      geom_line(df_post, mapping = aes(x = x, y = y)) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))


  } else stop("Invalid input.")

  return(gg)

}


#' Plotting posterior variances, standard deviations or precisions
#'
#' @param obj An object from \code{inference_stan} or \code{inference_inla}.
#' @keywords plot
#' @return A \link[ggplot2]{ggplot} object with the plot
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_posterior_variance <- function(obj){

  if (class(obj) == "mmp_stan"){
    df <- df_posterior_variances(obj, "variance")
    gg <- ggplot(df, aes(x = x, y = ..density..)) + geom_histogram(col = gray(0.5), fill = "#8E8D8A", bins = 40) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))
  } else if (class(obj) == "mmp_inla"){

    df <- df_posteriors_inla(obj, "variance")
    gg <- ggplot() +
      geom_line(df, mapping = aes(x = x, y = y)) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))

  } else stop("Invalid input.")

  return(gg)

}

#' @rdname plot_posterior_variance
plot_posterior_stdev <- function(obj){

  if (class(obj) == "mmp_stan"){
    df <- df_posterior_variances(obj, "stdev")
    gg <- ggplot(df, aes(x = x, y = ..density..)) + geom_histogram(col = gray(0.5), fill = "#8E8D8A", bins = 40) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))
  } else if (class(obj) == "mmp_inla"){

    df <- df_posteriors_inla(obj, "stdev")
    gg <- ggplot() +
      geom_line(df, mapping = aes(x = x, y = y)) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))

  } else stop("Invalid input.")

  return(gg)

}

#' @rdname plot_posterior_variance
plot_posterior_precision <- function(obj){

  if (class(obj) == "mmp_stan"){
    df <- df_posterior_variances(obj, "precision")
    gg <- ggplot(df, aes(x = x, y = ..density..)) + geom_histogram(col = gray(0.5), fill = "#8E8D8A", bins = 40) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))
  } else if (class(obj) == "mmp_inla"){

    df <- df_posteriors_inla(obj, "precision")
    gg <- ggplot() +
      geom_line(df, mapping = aes(x = x, y = y)) +
      facet_wrap(~param, labeller = label_parsed, scales = "free") +
      # theme(strip.text = element_text(size = 14, color = "white")) +
      ylab("Density") +
      theme(axis.title.x = element_blank()) +
      theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
            panel.grid.major = element_line(color = gray(0.85)),
            panel.grid.minor = element_line(color = gray(0.92))) +
      theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
            strip.text = element_text(color = "black", size = 15))

  } else stop("Invalid input.")

  return(gg)

}


#' Extract the posterior of the random effects in the model for inference done with Stan
#'
#' @param obj An object from \code{inference_stan}.
#' @param effname Name of the effect, same name as in the data.
#' @keywords posterior
#' @return Returns a matrix with the posterior samples of the chosen effect
#' @examples
#' \dontrun{
#' extract_posterior_effects(res_stan, "a")
#' }

extract_posterior_effects <- function(obj, effname){

  stopifnot(class(obj) == "mmp_stan")

  samps <- rstan::extract(obj$stan, "effects")$effects

  # find which indexes this effect belongs to
  which_eff <- which(names(obj$prior$data$random) == effname)

  return(
    samps[,(obj$stan_data$effect_index_start[which_eff]) + 1:obj$stan_data$effect_sizes[which_eff]]
  )

}



#' Extract the posterior variance of the random effects in the model for inference done with Stan
#'
#' @param obj An object from \code{inference_stan}.
#' @param param Name of the variance parameter, which is the same as the name of the corresponding
#' random effect in the data
#' @keywords posterior
#' @return Returns a vector with the posterior samples of the chosen variance parameter on variance scale
#' @examples
#' \dontrun{
#' extract_posterior_effects(res_stan, "a")
#' }

extract_posterior_variance <- function(obj, param){

  stopifnot(class(obj) == "mmp_stan")

  samps <- rstan::extract(obj$stan, "theta")$theta

  # find which indexes this effect belongs to
  which_eff <- which(sapply(obj$prior$prior_data$cw_priors, function(x) x$name) == param)

  return(exp(samps[,which_eff]))

}


#' Plotting several posterior distributions
#'
#' Function for plotting the posterior distributions of the random effect variances
#' on the scale of the tree parameterization.
#' @param objs A names list with objects of class \code{mmp_stan} from \code{inference_stan}, can be any length
#' (but typically length two for one prior (\code{use_likelihood = FALSE}) and posterior, or two posteriors).
#' @param param A string indicating parameterization of plot.
#' \code{"prior"} for scale of parameters,
#' \code{"variance"}, \code{"stdev"}, \code{"precision"} and \code{"logvariance"} are also possible.
#' @keywords plot, prior, posterior
#' @return A \link[ggplot2]{ggplot} with the posterior distributions.
#' @details We cannot sample from a Jeffreys' prior since it is improper.
#' If Jeffreys' prior is used for the total variance, the prior will be changed to a Gaussian(0,1) prior on
#' the log total variance. This means that it does not make sense to look at the variances/standard deviations/precisions,
#' but the variance proportions will be correct.
#' See also \link[makemyprior]{makemyprior_plotting}.

plot_several_posterior_stan <- function(objs, param = c("prior", "variance", "stdev", "precision", "logvariance")){

  if (class(objs) != "list" || any(is.null(names(objs)))) stop("Provide a named list with objects from 'inference_stan'.", call. = FALSE)
  if (any(sapply(objs, class) != "mmp_stan")) stop("The list 'objs' must consist of objects from 'inference_stan'.", call. = FALSE)
  param <- match.arg(param)

  df <- data.frame()
  if (param == "prior"){
    for (ind in 1:length(objs)){
      tmp <- make_dataframe_for_plotting("posterior", objs[[ind]])
      tmp$param2 <- names(objs)[ind]
      df <- rbind(df, tmp)
    }
  } else {
    for (ind in 1:length(objs)){
      if (param == "logvariance") {
        tmp <- df_posterior_variances(objs[[ind]], "variance")
        tmp$x <- log(tmp$x)
      } else {
        tmp <- df_posterior_variances(objs[[ind]], param)
      }
      tmp$param2 <- names(objs)[ind]
      df <- rbind(df, tmp)
    }
  }

  df$param2 <- factor(df$param2, levels = names(objs))

  gg <- ggplot() +
    geom_histogram(data = df, mapping = aes(x = x, y = ..density.., fill = param2),
                   col = gray(0.5), bins = 40, alpha = 1/(length(objs)+1), position = position_identity()) +
    facet_wrap(~ param, labeller = label_parsed, scales = "free") +
    scale_fill_viridis_d(option = "C", end = 0.7) +
    ylab("Density") +
    theme(axis.title.x = element_blank()) +
    theme(legend.title = element_blank(), legend.position = "bottom") +
    theme(panel.background = element_rect(fill ="white", color = gray(0.5)),
          panel.grid.major = element_line(color = gray(0.85)),
          panel.grid.minor = element_line(color = gray(0.92))) +
    theme(strip.background = element_rect(fill = "white", color = gray(0.5)),
          strip.text = element_text(color = "black", size = 15))

  return(gg)

}





# extracting some posterior values from stan object
make_posterior_summary_stan <- function(res){

  if (class(res) != "mmp_stan") stop("An object of class 'mmp_stan' must be provided.")

  prior_obj <- res$prior

  df <- data.frame(par = c(), mean = c(), median = c(), sd = c())

  samps <- rstan::extract(res$stan, "theta")$theta

  # for CW priors:
  for (i in 1:length(prior_obj$prior_data$cw_priors)){

    if (prior_obj$prior_data$cw_priors[[i]]$prior != ""){

      xx <- exp(samps[,i])
      title <- paste0("sigma^2", "[", prior_obj$prior_data$cw_priors[[i]]$name, "]")

      df <- rbind(df, data.frame(par = title, mean = mean(xx), median = median(xx), sd = sd(xx)))

    }

  }

  # for total variances
  for (i in seq_len(length(prior_obj$prior_data$total_variance))){

    if (is.null(prior_obj$prior_data$total_variance[[i]]$prior)) next

    xx <- rowSums(exp(samps[,res$stan_data$which_hd]))

    title <- paste0(c("V", "[",
                    prior_obj$prior_data$total_variance[[i]]$name,
                    "]"), collapse = "")

    df <- rbind(df, data.frame(par = title, mean = mean(xx), median = median(xx), sd = sd(xx)))

  }

  # for HD priors
  for (i in seq_len(length(prior_obj$prior_data$weights))){

    if (prior_obj$prior_data$weights[[i]]$prior == "pc"){

      # calculate the correct variances over and under fraction bar
      ind2 <- res$stan_data$row_index_hd_pr_plot[i]
      over <- rowSums(as.matrix(exp(samps[,res$stan_data$w_o[ind2,] == 1])))
      under <- rowSums(as.matrix(exp(samps[,res$stan_data$w_u[ind2,] == 1])))

      t_under <- as.character(prior_obj$prior_data$weights[[i]]$name)
      t_over <- as.character(get_node_name(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$param$above_node))
      title <- sprintf("w[%s/%s]", t_over, t_under)

      df <- rbind(df, data.frame(par = title, mean = mean(over/under), median = median(over/under), sd = sd(over/under)))

    } else { # dirichlet

      for (ind in 1:(prior_obj$prior_data$weights[[i]]$no_children-1)){

        ind2 <- res$stan_data$row_index_hd_pr_plot[i]+ind-1

        over <- rowSums(as.matrix(exp(samps[,res$stan_data$w_o[ind2,] == 1])))
        under <- rowSums(as.matrix(exp(samps[,res$stan_data$w_u[ind2,] == 1])))

        t_under <- paste0(get_node_name(prior_obj$node_data, get_leaf_nodes(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$id)), sep = "", collapse = ",")
        t_over <- as.character(get_node_name(prior_obj$node_data, prior_obj$prior_data$weights[[i]]$children[ind]))
        title <- sprintf("w[%s/%s]", t_over, t_under)

        df <- rbind(df, data.frame(par = title, mean = mean(over/under), median = median(over/under), sd = sd(over/under)))

      }

    }

  }


  # intercept
  if (prior_obj$use_intercept){
    samps <- rstan::extract(res$stan, "intercept")$intercept

    df <- rbind(df, data.frame(par = "intercept", mean = mean(samps), median = median(samps), sd = sd(samps)))

  }

  # fixed effects
  if (length(prior_obj$data$fixed) > 0){
    samps <- rstan::extract(res$stan, "coeff")$coeff
  }
  for (ind in seq_along(prior_obj$data$fixed)){

    title <- row.names(prior_obj$prior_fixed)[ind]

    df <- rbind(df, data.frame(par = title, mean = mean(samps[,ind]), median = median(samps[,ind]), sd = sd(samps[,ind])))

  }

  names(df)[1] <- "Param."

  return(df)

}


# extracting some posterior values from inla object
make_posterior_summary_inla <- function(res){

  if (class(res) != "mmp_inla") stop("An object of class 'mmp_inla' must be provided.")

  prior_obj <- res$prior

  tmp <- res$inla$summary.hyperpar[, c("mean", "0.5quant", "sd")]
  names(tmp) <- c("mean", "median", "sd")
  for (ind in seq_len(nrow(tmp))){
    if (row.names(tmp)[ind] == "Precision for the Gaussian observations"){
      row.names(tmp)[ind] <- "1/sigma[eps]^2"
    } else {
      row.names(tmp)[ind] <- paste0("1/sigma[", strsplit(row.names(tmp)[ind], "Precision for ")[[1]][2], "]^2", collapse = "")
    }
  }

  if (nrow(res$inla$summary.fixed) > 0){
    tmp2 <- res$inla$summary.fixed
    row.names(tmp2)[row.names(tmp2) == "(Intercept)"] <- "intercept"
    tmp2 <- tmp2[, c("mean", "0.5quant", "sd")]
    names(tmp2) <- c("mean", "median", "sd")
  } else tmp2 <- data.frame()

  tmp3 <- rbind(tmp, tmp2)

  tmp3 <- cbind(data.frame(par = row.names(tmp3)), tmp3)
  names(tmp3)[1] <- "Param."
  row.names(tmp3) <- 1:nrow(tmp3)

  return(tmp3)

}













